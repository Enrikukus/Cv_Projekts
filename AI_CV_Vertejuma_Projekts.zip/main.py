import json
import os
from pathlib import Path
from datetime import datetime
from openai import OpenAI

MODEL_NAME = "gemini-1.5-flash"
TEMPERATURE = 0.3
API_KEY = os.getenv("OPENAI_API_KEY")

Path("outputs").mkdir(exist_ok=True)
Path("sample_inputs").mkdir(exist_ok=True)

def read_file(filepath: str) -> str:
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read().strip()

def create_prompt(jd_text: str, cv_text: str) -> str:
    prompt = f"""
Tu esi HR speciālists, kurš analizē kandidātu CV atbilstību darba aprakstam.
Salīdzini abas sadaļas un sniedz JSON atbildi ar šādu struktūru:
{{
  "match_score": 0-100,
  "summary": "Īss apraksts, cik labi CV atbilst JD.",
  "strengths": ["Galvenās prasmes/pieredze no CV, kas atbilst JD"],
  "missing_requirements": ["Svarīgas JD prasības, kas CV nav redzamas"],
  "verdict": "strong match | possible match | not a match"
}}

=== DARBA APRĀKSTS ===
{jd_text}

=== KANDIDĀTA CV ===
{cv_text}
"""
    with open("prompt.md", "w", encoding="utf-8") as f:
        f.write(prompt)
    return prompt

def call_model(prompt: str) -> dict:
    client = OpenAI(api_key=API_KEY)

    response = client.chat.completions.create(
        model=MODEL_NAME,
        temperature=TEMPERATURE,
        messages=[
            {"role": "system", "content": "Tu esi HR analītiķis, kas vērtē CV atbilstību JD."},
            {"role": "user", "content": prompt},
        ],
        response_format={"type": "json_object"}
    )

    result_text = response.choices[0].message.content
    try:
        result = json.loads(result_text)
    except json.JSONDecodeError:
        result = {"error": "Invalid JSON", "raw_response": result_text}
    return result

def save_json(data: dict, filename: str):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def generate_report(data: dict, filename: str):
    report = f"""# CV Atbilstības Pārskats

**Novērtējuma datums:** {datetime.now().strftime("%Y-%m-%d %H:%M")}
**Atbilstības punktu skaits:** {data.get('match_score', 'N/A')}

---

### 📝 Kopsavilkums
{data.get('summary', 'Nav kopsavilkuma.')}

---

### ✅ Stiprās puses
{"".join(f"- {s}\n" for s in data.get('strengths', []))}

---

### ⚠️ Trūkstošās prasības
{"".join(f"- {m}\n" for m in data.get('missing_requirements', []))}

---

### 💡 Spriedums
**{data.get('verdict', 'N/A')}**
"""
    with open(filename, "w", encoding="utf-8") as f:
        f.write(report)

def main():
    jd_text = read_file("sample_inputs/jd.txt")
    cvs = ["cv1.txt", "cv2.txt", "cv3.txt"]

    for cv_file in cvs:
        cv_path = f"sample_inputs/{cv_file}"
        cv_text = read_file(cv_path)

        prompt = create_prompt(jd_text, cv_text)
        result = call_model(prompt)

        base_name = cv_file.split(".")[0]
        json_path = f"outputs/{base_name}.json"
        report_path = f"outputs/{base_name}_report.md"

        save_json(result, json_path)
        generate_report(result, report_path)

        print(f"✅ Sagatavots: {json_path} un {report_path}")

if __name__ == "__main__":
    main()
